#pragma once

#include <stdint.h>
#include <stdbool.h>

#define MAX_TRAJECTORY_POINTS      100

#define DEFAULT_FLIGHT_HEIGHT      0.30f
#define HOVER_TIME_MS              5000U

#define TRAJ_REACH_DISTANCE        0.05f
#define TRAJ_YAW_TOL_RAD           0.08726646f   // 5 deg
#define TRAJ_MAX_POS_STEP          0.10f
#define TRAJ_MAX_YAW_STEP_RAD      0.08726646f   // 5 deg per 20 ms, same as old M_PI/36 logic

#define FORWARD_SPEED              0.10f
#define BACKWARD_SPEED             0.10f
#define FINAL_FORWARD_TIMEOUT_MS   2500U
#define COLLISION_STOP_TIME_MS     300U
#define SERVO_DEPLOY_WAIT_MS       1000U
#define BACKUP_TIME_MS             1800U
#define LANDING_TIMEOUT_MS         6000U

#define COLLISION_MIN_CMD_SPEED    0.06f
#define COLLISION_MIN_REAL_SPEED   0.025f
#define COLLISION_COUNT_THRESHOLD  12U

// CRTP port used by the older working trajectory sender.
#define TRAJECTORY_CRTP_PORT       0x0F

typedef enum {
  TRAJ_IDLE = 0,
  TRAJ_HOVERING,
  TRAJ_FOLLOWING,
  TRAJ_FLY_FORWARD,
  TRAJ_CONTACT,
  TRAJ_SERVO_CW,
  TRAJ_FLY_BACKWARD,
  TRAJ_LANDING,
  TRAJ_FINISHED
} TrajectoryState;

typedef enum {
  TRAJ_CMD_STOP = 0,
  TRAJ_CMD_BODY_VEL_HEIGHT,
  TRAJ_CMD_POSITION
} TrajectoryCommandMode;

typedef struct __attribute__((packed)) {
  float x;
  float y;
} TrajectoryPoint;

typedef struct {
  float last_x;
  float last_y;
  uint32_t last_time_ms;
  uint32_t low_progress_counter;
  bool initialized;
  bool collision_detected;
} CollisionDetectionState;

typedef struct {
  TrajectoryState state;
  CollisionDetectionState collision;

  uint16_t traj_index;
  uint32_t state_start_time_ms;

  float drone_x;
  float drone_y;
  float drone_z;
  float drone_yaw_deg;

  TrajectoryCommandMode cmd_mode;

  // For TRAJ_CMD_BODY_VEL_HEIGHT
  float cmd_vx_body;
  float cmd_vy_body;
  float cmd_height;
  float cmd_yaw_rate_deg_s;

  // For TRAJ_CMD_POSITION
  float cmd_x;
  float cmd_y;
  float cmd_z;
  float cmd_yaw_deg;

  bool servo_cw_sent;
} TrajectoryTrackingContext;

extern TrajectoryPoint trajectory_buffer[MAX_TRAJECTORY_POINTS];
extern int trajectory_length;
extern bool trajectory_received;

void trajectoryTrackingInit(void);
void trajectoryTrackingUpdateState(float current_x, float current_y, float current_z, float current_yaw_deg);
void trajectoryTrackingGetCommand(TrajectoryCommandMode *mode,
                                  float *a,
                                  float *b,
                                  float *c,
                                  float *d);
bool trajectoryTrackingIsActive(void);
TrajectoryState trajectoryTrackingGetState(void);
void clearTrajectory(void);
