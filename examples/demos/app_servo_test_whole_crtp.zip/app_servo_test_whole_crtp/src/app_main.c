/**
 * app_main.c - CRTP trajectory tracking + nominal contact + servo CW + fly-back + landing
 *
 * This version intentionally follows the older working style:
 *   - stateEstimate.x/y/z/yaw are read through the log framework
 *   - trajectory points are received by CRTP_PORT_TRAJECTORY in trajectory_tracking.c
 *   - trajectory following sends absolute x/y/z/yaw position setpoints
 *   - forward/backward/landing use body-frame velocity + absolute height
 */

#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "app.h"
#include "FreeRTOS.h"
#include "task.h"
#include "debug.h"
#include "commander.h"
#include "log.h"

#include "trajectory_tracking.h"
#include "servo_test.h"

#define DEBUG_MODULE "APP"
#define APP_LOOP_PERIOD_MS     20U
#define COMMANDER_APP_PRIORITY 3

static setpoint_t setpoint;

static void send_body_velocity_height_setpoint(float vx_body, float vy_body, float height, float yaw_rate_deg_s)
{
  memset(&setpoint, 0, sizeof(setpoint_t));

  setpoint.mode.x = modeVelocity;
  setpoint.mode.y = modeVelocity;
  setpoint.mode.z = modeAbs;
  setpoint.mode.yaw = modeVelocity;

  setpoint.velocity.x = vx_body;
  setpoint.velocity.y = vy_body;
  setpoint.position.z = height;
  setpoint.attitudeRate.yaw = yaw_rate_deg_s;

  // Same convention as the old working setHoverSetpoint(): vx/vy are body-frame.
  setpoint.velocity_body = true;

  commanderSetSetpoint(&setpoint, COMMANDER_APP_PRIORITY);
}

static void send_position_setpoint(float x, float y, float z, float yaw_deg)
{
  memset(&setpoint, 0, sizeof(setpoint_t));

  setpoint.mode.x = modeAbs;
  setpoint.mode.y = modeAbs;
  setpoint.mode.z = modeAbs;
  setpoint.mode.yaw = modeAbs;

  setpoint.position.x = x;
  setpoint.position.y = y;
  setpoint.position.z = z;
  setpoint.attitude.yaw = yaw_deg;

  commanderSetSetpoint(&setpoint, COMMANDER_APP_PRIORITY);
}

static void send_stop_setpoint(void)
{
  memset(&setpoint, 0, sizeof(setpoint_t));
  commanderSetSetpoint(&setpoint, COMMANDER_APP_PRIORITY);
}

void appMain(void)
{
  DEBUG_PRINT("CRTP trajectory + servo app starting\n");

  vTaskDelay(M2T(3000));

  logVarId_t idStateX = logGetVarId("stateEstimate", "x");
  logVarId_t idStateY = logGetVarId("stateEstimate", "y");
  logVarId_t idStateZ = logGetVarId("stateEstimate", "z");
  logVarId_t idStateYaw = logGetVarId("stateEstimate", "yaw");

  servoControlInit();
  trajectoryTrackingInit();

  DEBUG_PRINT("Send CRTP trajectory points to port 0x0F, end with NaN/NaN, then set traj.start=1\n");

  TickType_t xLastWakeTime = xTaskGetTickCount();

  while (1) {
    const float state_x = logGetFloat(idStateX);
    const float state_y = logGetFloat(idStateY);
    const float state_z = logGetFloat(idStateZ);
    const float state_yaw_deg = logGetFloat(idStateYaw);

    trajectoryTrackingUpdateState(state_x, state_y, state_z, state_yaw_deg);

    TrajectoryCommandMode mode = TRAJ_CMD_STOP;
    float a = 0.0f;
    float b = 0.0f;
    float c = 0.0f;
    float d = 0.0f;

    trajectoryTrackingGetCommand(&mode, &a, &b, &c, &d);

    if (mode == TRAJ_CMD_POSITION) {
      // a=x, b=y, c=z, d=yaw_deg
      send_position_setpoint(a, b, c, d);
    } else if (mode == TRAJ_CMD_BODY_VEL_HEIGHT) {
      // a=vx_body, b=vy_body, c=height, d=yaw_rate_deg_s
      send_body_velocity_height_setpoint(a, b, c, d);
    } else {
      send_stop_setpoint();
    }

    vTaskDelayUntil(&xLastWakeTime, M2T(APP_LOOP_PERIOD_MS));
  }
}
